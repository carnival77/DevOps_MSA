package io.spring.foodservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FoodserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
